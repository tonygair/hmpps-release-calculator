# ada-hmpps_release_factory

Generated 20260508-200455 by ada_bundle.sh (Dark Factory inversion-architecture pipeline
for Ada / SPARK 2014).

## What this bundle contains

```
ada-hmpps_release_factory/
├── README.md                 — this file
├── design.md                 — pointer to the canonical spec
├── audit-trail/
│   ├── 00-planner/           — natural-language goal + planner output
│   ├── 01-coder/             — request to qwen3-coder + raw response
│   └── 02-prover/            — gnatprove summary + full stdout
├── implementation/           — final source files (spec + body + driver + gpr)
└── tests/                    — per-gate compile/run/prove logs
```

## Pipeline gates passed

- 01-spec-compile.log
- 02-body-compile.log
- 03-bind-link.log
- 04-runtime.log
- 05-gnatprove.log

## Reproducing this bundle

Requires:
- Gertrude (or any Linux host) with GNAT 13+ and gnatprove 13.2.1+
- ollama on the same host with `qwen3-coder:30b-a3b-q4_K_M`
- ssh access to the build host

Run:
```bash
./ada_bundle.sh --name hmpps_release_factory \
                --spec implementation/hmpps_release.ads \
                --body implementation/hmpps_release.adb \
                --driver implementation/hmpps_release_demo.adb \
                --gpr implementation/hmpps_release.gpr
```
