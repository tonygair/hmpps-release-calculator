# ada-hmpps_release_factory — design

The package specification `hmpps_release.ads` is the canonical design document
for this bundle. It defines:

- The exported types and their value ranges
- The procedure / function signatures
- The Pre/Post aspects encoding the contract obligations the body satisfies
- (Where applicable) the private-part expression-function bodies that
  give SPARK proof visibility into otherwise-opaque accessors

Read `implementation/hmpps_release.ads` for the full spec.
