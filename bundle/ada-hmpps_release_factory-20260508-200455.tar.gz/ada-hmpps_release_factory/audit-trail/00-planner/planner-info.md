Planner: human (Claude on M5 Max). The .ads in this directory IS the planner output.
